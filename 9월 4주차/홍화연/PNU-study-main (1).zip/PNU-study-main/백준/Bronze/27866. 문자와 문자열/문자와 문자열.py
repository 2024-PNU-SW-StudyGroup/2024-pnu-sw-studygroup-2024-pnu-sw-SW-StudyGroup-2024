S = str(input())
i = int(input())

s_lst = list(S)
print(s_lst[i-1])
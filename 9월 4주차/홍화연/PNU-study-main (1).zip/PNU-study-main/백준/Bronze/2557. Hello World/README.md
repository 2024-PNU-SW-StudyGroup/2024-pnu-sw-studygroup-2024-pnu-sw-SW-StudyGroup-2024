# [Bronze V] Hello World - 2557 

[문제 링크](https://www.acmicpc.net/problem/2557) 

### 성능 요약

메모리: 31120 KB, 시간: 32 ms

### 분류

구현

### 제출 일자

2024년 9월 25일 17:42:29

### 문제 설명

<p>
	Hello World!를 출력하시오.</p>

### 입력 

 <p>
	없음</p>

### 출력 

 <p>
	Hello World!를 출력하시오.</p>


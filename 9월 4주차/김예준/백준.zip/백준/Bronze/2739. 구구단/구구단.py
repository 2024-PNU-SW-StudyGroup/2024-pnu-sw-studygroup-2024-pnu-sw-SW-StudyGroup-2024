n = int(input())
a = 0
for i in range(9) :
    a += 1
    print(n,"*",a,"=",n*a) 
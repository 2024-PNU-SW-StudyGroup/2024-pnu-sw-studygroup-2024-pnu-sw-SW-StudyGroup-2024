n = int(input())
a = 0
for i in range (n) :
    a += 1
    print("*"*a)